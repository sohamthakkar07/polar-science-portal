import React from 'react';
import { PolarTopic } from '../../types/polar';
import { NavTab } from '../layout/Navbar';
import { ArrowRight, Layers, Database, BookOpen, Award } from 'lucide-react';

interface PolarTopicGridProps {
  onSelectTopic: (topic: PolarTopic) => void;
  onNavigate: (tab: NavTab) => void;
}

interface TopicCardItem {
  id: PolarTopic;
  title: string;
  emoji: string;
  tagline: string;
  accentColor: string;
  stats: string;
}

export const PolarTopicGrid: React.FC<PolarTopicGridProps> = ({ onSelectTopic, onNavigate }) => {
  const topics: TopicCardItem[] = [
    {
      id: 'Cryosphere',
      title: 'Cryosphere',
      emoji: '🧊',
      tagline: 'Sea ice thermodynamics, ice sheet stability, permafrost thaw, and albedo feedbacks.',
      accentColor: 'from-sky-500/20 to-sky-950/40 border-sky-500/30 text-sky-400',
      stats: '1979–2024 NSIDC Time Series • 3 Datasets',
    },
    {
      id: 'Climate',
      title: 'Climate',
      emoji: '🌡️',
      tagline: 'Polar amplification, jet stream modulation, polar vortex dynamics, and paleoclimate ice cores.',
      accentColor: 'from-amber-500/20 to-amber-950/40 border-amber-500/30 text-amber-400',
      stats: '800,000-Yr EPICA Record • ERA5 Reanalysis',
    },
    {
      id: 'Ocean',
      title: 'Ocean',
      emoji: '🌊',
      tagline: 'Antarctic Circumpolar Current, deep water formation, and Kongsfjorden Atlantic water intrusions.',
      accentColor: 'from-blue-500/20 to-blue-950/40 border-blue-500/30 text-blue-400',
      stats: 'Argo Floats • IndARC Mooring (192m)',
    },
    {
      id: 'Atmosphere',
      title: 'Atmosphere',
      emoji: '🌬️',
      tagline: 'Stratospheric ozone chemistry, Dobson spectrophotometry, polar night vortex, and auroral physics.',
      accentColor: 'from-teal-500/20 to-teal-950/40 border-teal-500/30 text-teal-400',
      stats: 'Halley VI & Maitri Observations • NASA Ozone Watch',
    },
    {
      id: 'Polar Life',
      title: 'Polar Life',
      emoji: '🐧',
      tagline: 'Emperor penguin fast-ice colonies, polar bear hunting ecology, and Antarctic krill swarms.',
      accentColor: 'from-emerald-500/20 to-emerald-950/40 border-emerald-500/30 text-emerald-400',
      stats: 'SCAR Biodiversity • GBIF & OBIS Records',
    },
    {
      id: 'Remote Sensing',
      title: 'Remote Sensing',
      emoji: '🛰️',
      tagline: 'ICESat-2 photon lidar, passive microwave radiometers, and ISRO polar ground telemetry.',
      accentColor: 'from-indigo-500/20 to-indigo-950/40 border-indigo-500/30 text-indigo-400',
      stats: 'NASA Earthdata • ISRO Bharati Telemetry',
    },
    {
      id: 'Glaciers',
      title: 'Glaciers',
      emoji: '🏔️',
      tagline: 'High Himalayan glacier mass balances, ice velocity, terminus retreat, and supraglacial lakes.',
      accentColor: 'from-cyan-500/20 to-cyan-950/40 border-cyan-500/30 text-cyan-400',
      stats: 'NCPOR Himansh Observatory (4,080m) • Chandra Basin',
    },
    {
      id: 'Research',
      title: 'Research',
      emoji: '🔬',
      tagline: 'Peer-reviewed polar discoveries, DOI registries, and international polar science collaborations.',
      accentColor: 'from-violet-500/20 to-violet-950/40 border-violet-500/30 text-violet-400',
      stats: 'Nature, JGR & Polar Science Papers with DOIs',
    },
    {
      id: 'Indian Polar Programme',
      title: 'Indian Polar Programme',
      emoji: '🇮🇳',
      tagline: 'Historical timeline from Operation Gangotri (1981) to Maitri, Bharati, Himadri, and Himansh.',
      accentColor: 'from-orange-500/20 to-orange-950/40 border-orange-500/30 text-orange-400',
      stats: '43 Antarctic Expeditions • 4 Active Stations',
    },
  ];

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-10">
        <div>
          <div className="flex items-center gap-2 text-frost-cyan text-xs font-bold uppercase tracking-wider mb-2">
            <Layers className="w-4 h-4" />
            <span>Structured Scientific Domains</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white font-mono">
            Explore Polar Science Topics
          </h2>
          <p className="text-sm text-slate-400 mt-1 max-w-2xl">
            Each topic unifies verified datasets, research papers, geographic locations, student lessons, and interactive quizzes.
          </p>
        </div>

        <button
          onClick={() => onNavigate('learn')}
          className="mt-4 md:mt-0 inline-flex items-center gap-2 text-xs font-bold text-frost-cyan hover:text-white transition-colors"
        >
          <span>View All Learning Modules</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {topics.map((topic) => (
          <div
            key={topic.id}
            onClick={() => onSelectTopic(topic.id)}
            className={`p-6 rounded-2xl bg-gradient-to-br ${topic.accentColor} bg-polar-900/90 border hover:border-white/40 transition-all cursor-pointer group shadow-lg flex flex-col justify-between`}
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-3xl p-2 rounded-xl bg-polar-950/60 border border-polar-800 shadow-inner">
                  {topic.emoji}
                </span>
                <span className="text-[11px] font-mono font-medium text-slate-400 bg-polar-950/80 px-2 py-0.5 rounded border border-polar-800">
                  {topic.stats}
                </span>
              </div>
              <h3 className="text-lg font-bold text-white group-hover:text-frost-cyan transition-colors mb-2">
                {topic.title}
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed mb-4">
                {topic.tagline}
              </p>
            </div>

            <div className="pt-3 border-t border-polar-800/60 flex items-center justify-between text-xs font-semibold text-frost-cyan group-hover:text-white">
              <span>Explore Domain</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
