import React from 'react';
import { Compass, GraduationCap, Microscope, Sparkles, MapPin, BarChart2, ShieldCheck, ArrowRight, BookOpen, Layers } from 'lucide-react';
import { useAudience } from '../../context/AudienceContext';
import { NavTab } from '../layout/Navbar';

interface HeroSectionProps {
  onSelectTab: (tab: NavTab) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onSelectTab }) => {
  const { setMode } = useAudience();

  const handleStudentClick = () => {
    setMode('student');
    onSelectTab('learn');
  };

  const handleResearcherClick = () => {
    setMode('researcher');
    onSelectTab('data');
  };

  return (
    <section className="relative w-full overflow-hidden pt-12 pb-20 px-4 sm:px-6 lg:px-8 bg-polar-gradient border-b border-polar-800/80">
      {/* Aurora Ambient Glow Effects */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-frost-cyan/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-10 right-1/4 w-96 h-96 bg-frost-teal/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-6xl mx-auto text-center relative z-10">
        {/* Verification Pill */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-polar-900/90 border border-frost-cyan/30 text-frost-cyan text-xs font-semibold shadow-polar-glow mb-6 backdrop-blur-md">
          <ShieldCheck className="w-4 h-4 text-frost-teal" />
          <span>Integrated Polar Science Outreach & Knowledge Repository</span>
          <span className="hidden sm:inline text-slate-500">•</span>
          <span className="hidden sm:inline text-slate-400 font-normal">NCPOR • NSIDC • NASA • BAS • SCAR</span>
        </div>

        {/* Core Headlines from Specification */}
        <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black text-white tracking-tight leading-tight mb-4 font-mono">
          The Polar World <br className="hidden sm:inline" />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-frost-cyan via-white to-frost-teal">
            Is Full of Stories.
          </span>
        </h1>

        <p className="text-xl sm:text-2xl font-semibold text-slate-200 mb-6 tracking-wide">
          We make them easier to discover.
        </p>

        <p className="max-w-3xl mx-auto text-sm sm:text-base text-slate-300 leading-relaxed mb-10">
          Explore real polar science, datasets, research, expeditions, and discoveries through an interactive experience designed for everyone. Connecting authoritative global repositories without replacing them.
        </p>

        {/* Action Call-to-Action Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-4 mb-16">
          <button
            onClick={() => onSelectTab('explore')}
            className="px-6 py-3.5 rounded-xl bg-gradient-to-r from-frost-cyan to-polar-500 hover:from-sky-300 hover:to-polar-400 text-polar-950 font-bold text-sm shadow-polar-glow hover:shadow-polar-glow-lg transition-all flex items-center gap-2 group"
          >
            <Compass className="w-4 h-4 group-hover:rotate-45 transition-transform" />
            <span>Start Exploring</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={handleStudentClick}
            className="px-5 py-3.5 rounded-xl bg-polar-900/90 hover:bg-polar-850 border border-frost-cyan/40 hover:border-frost-cyan text-frost-cyan font-bold text-sm transition-all flex items-center gap-2 shadow-sm backdrop-blur-md"
          >
            <GraduationCap className="w-4 h-4 text-frost-cyan" />
            <span>I'm a Student</span>
          </button>

          <button
            onClick={handleResearcherClick}
            className="px-5 py-3.5 rounded-xl bg-polar-900/90 hover:bg-polar-850 border border-indigo-500/40 hover:border-indigo-400 text-indigo-300 font-bold text-sm transition-all flex items-center gap-2 shadow-sm backdrop-blur-md"
          >
            <Microscope className="w-4 h-4 text-indigo-300" />
            <span>I'm a Researcher</span>
          </button>
        </div>

        {/* Feature Pillars / Verified Metrics Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-left">
          <div className="p-4 rounded-2xl bg-polar-900/80 border border-polar-800/80 backdrop-blur-md">
            <div className="flex items-center gap-2 text-frost-cyan mb-1">
              <MapPin className="w-4 h-4" />
              <span className="text-xs font-bold uppercase tracking-wider">Polar Explorer</span>
            </div>
            <div className="text-xl font-bold text-white font-mono">11+ Verified Stations</div>
            <p className="text-xs text-slate-400 mt-1">Maitri, Bharati, Himadri, McMurdo with live coordinates & climate logs.</p>
          </div>

          <div className="p-4 rounded-2xl bg-polar-900/80 border border-polar-800/80 backdrop-blur-md">
            <div className="flex items-center gap-2 text-frost-teal mb-1">
              <BarChart2 className="w-4 h-4" />
              <span className="text-xs font-bold uppercase tracking-wider">Data Stories</span>
            </div>
            <div className="text-xl font-bold text-white font-mono">45+ Years Data</div>
            <p className="text-xs text-slate-400 mt-1">NSIDC sea ice, NASA ozone hole & NCPOR meteorological time series.</p>
          </div>

          <div className="p-4 rounded-2xl bg-polar-900/80 border border-polar-800/80 backdrop-blur-md">
            <div className="flex items-center gap-2 text-amber-400 mb-1">
              <BookOpen className="w-4 h-4" />
              <span className="text-xs font-bold uppercase tracking-wider">Dual Explanations</span>
            </div>
            <div className="text-xl font-bold text-white font-mono">ELI-15 & Deep Science</div>
            <p className="text-xs text-slate-400 mt-1">Student-friendly analogies alongside researcher-grade thermodynamics.</p>
          </div>

          <div className="p-4 rounded-2xl bg-polar-900/80 border border-polar-800/80 backdrop-blur-md">
            <div className="flex items-center gap-2 text-frost-saffron mb-1">
              <ShieldCheck className="w-4 h-4" />
              <span className="text-xs font-bold uppercase tracking-wider">100% Provenance</span>
            </div>
            <div className="text-xl font-bold text-white font-mono">Zero Hallucinations</div>
            <p className="text-xs text-slate-400 mt-1">Every DOI, measurement, and expedition linked directly to official sources.</p>
          </div>
        </div>
      </div>
    </section>
  );
};
