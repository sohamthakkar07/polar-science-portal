/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        polar: {
          950: '#040914',
          900: '#071326',
          850: '#0b1b33',
          800: '#0f2547',
          700: '#173663',
          600: '#224e8a',
          500: '#326bb5',
          400: '#4d8fe2',
          300: '#88d5f7',
          200: '#bfeaff',
          100: '#e0f7ff',
          50: '#f0faff',
        },
        frost: {
          cyan: '#38bdf8',
          teal: '#2dd4bf',
          emerald: '#34d399',
          amber: '#fbbf24',
          violet: '#a78bfa',
          rose: '#fb7185',
          saffron: '#f97316',
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
      },
      boxShadow: {
        'polar-glow': '0 0 25px -5px rgba(56, 189, 248, 0.25)',
        'polar-glow-lg': '0 0 45px -10px rgba(56, 189, 248, 0.35)',
        'ice-glow': '0 0 20px -3px rgba(136, 213, 247, 0.25)',
      },
      backgroundImage: {
        'polar-gradient': 'radial-gradient(ellipse at top, #0f2547 0%, #071326 60%, #040914 100%)',
        'aurora-gradient': 'linear-gradient(135deg, rgba(45,212,191,0.12) 0%, rgba(56,189,248,0.12) 50%, rgba(167,139,250,0.12) 100%)',
      }
    },
  },
  plugins: [],
}
