import React, { useState } from 'react';
import {
  Bot,
  Send,
  Sparkles,
  ShieldCheck,
  ExternalLink,
  BookOpen,
  Database,
  MapPin,
  FileText,
  AlertTriangle,
  RotateCcw
} from 'lucide-react';
import { RESEARCH_STATIONS } from '../../data/stations';
import { POLAR_DATASETS } from '../../data/datasets';
import { RESEARCH_PAPERS } from '../../data/researchPapers';
import { LEARNING_MODULES } from '../../data/learningModules';
import { POLAR_EXPEDITIONS } from '../../data/expeditions';
import { NavTab } from '../layout/Navbar';

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  simpleAnswer?: string;
  scientificExplanation?: string;
  relatedData?: { label: string; tab: NavTab; id?: string }[];
  sourcesUsed?: { name: string; org: string; url: string; doi?: string }[];
  isUngrounded?: boolean;
}

interface PolarAIProps {
  onNavigate: (tab: NavTab, detailId?: string) => void;
}

export const PolarAI: React.FC<PolarAIProps> = ({ onNavigate }) => {
  const [inputQuery, setInputQuery] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'assistant',
      text: 'Hello! I am Ask PolarVerse, your source-grounded polar science assistant. Ask me anything about Antarctic & Arctic climate, Maitri & Bharati stations, sea ice dynamics, ozone recovery, or Himalayan glaciers. Every claim I make is grounded directly in verified datasets and peer-reviewed papers.',
      sourcesUsed: [
        { name: 'NCPOR Polar Archives', org: 'NCPOR India', url: 'https://ncpor.res.in/' },
        { name: 'NSIDC Sea Ice Index', org: 'NSIDC / NASA', url: 'https://nsidc.org/data/g02135' }
      ]
    }
  ]);

  // Suggested prompts
  const suggestedPrompts = [
    'Why is Antarctica considered the world\'s largest desert?',
    'How do Indian stations Maitri and Bharati differ in science & location?',
    'What caused the 2023 Antarctic sea ice record low?',
    'How does India\'s IndARC mooring operate underwater in Svalbard?',
    'What was the Montreal Protocol and is the ozone hole recovering?'
  ];

  // Retrieval and response generation
  const handleSendMessage = (queryText?: string) => {
    const textToSend = queryText || inputQuery;
    if (!textToSend.trim() || isProcessing) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text: textToSend
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputQuery('');
    setIsProcessing(true);

    setTimeout(() => {
      const q = textToSend.toLowerCase();
      let responseMsg: ChatMessage;

      if (q.includes('desert') || q.includes('precipitation') || q.includes('dry')) {
        responseMsg = {
          id: `resp-${Date.now()}`,
          sender: 'assistant',
          text: 'Antarctica is officially the largest desert on Earth because deserts are defined strictly by annual precipitation (<250 mm/year). The Antarctic polar plateau receives under 50 mm of precipitation annually—far less than the Sahara.',
          simpleAnswer: 'Antarctica is so cold that air cannot hold moisture. Almost no new snow or rain falls in the interior, making it the driest and windiest place on Earth.',
          scientificExplanation: 'High atmospheric pressure over the South Pole creates a subsidence inversion. At -50°C, the saturation vapor pressure is virtually zero, preventing significant cloud condensation and snowfall.',
          relatedData: [
            { label: 'Explore South Pole Station', tab: 'explore', id: 'amundsen-scott' },
            { label: 'Learn Polar Cryosphere', tab: 'learn', id: 'learn-cryosphere-sea-ice' }
          ],
          sourcesUsed: [
            { name: 'NSIDC Parts of the Cryosphere', org: 'NSIDC', url: 'https://nsidc.org/learn/parts-cryosphere/ice-sheets' },
            { name: 'IPCC AR6 Working Group I', org: 'IPCC', url: 'https://www.ipcc.ch/' }
          ]
        };
      } else if (q.includes('maitri') || q.includes('bharati') || q.includes('indian station')) {
        responseMsg = {
          id: `resp-${Date.now()}`,
          sender: 'assistant',
          text: 'India operates two year-round Antarctic research stations: Maitri (established 1989 in Schirmacher Oasis, 70°S) and Bharati (established 2012 in Larsemann Hills, 69°S).',
          simpleAnswer: 'Maitri sits inland on rocky hills near freshwater Lake Priyadarshini and monitors weather and geomagnetism. Bharati is a futuristic station on the coast with satellite dishes that download data from ISRO satellites on every polar pass.',
          scientificExplanation: 'Maitri focuses on 34-year synoptic surface meteorology, crustal deformation GPS, and limnology. Bharati specializes in Gondwana supercontinent correlation, aerosol optical depth, and real-time remote sensing telemetry for ISRO earth observation satellites.',
          relatedData: [
            { label: 'Maitri Meteorological Time Series', tab: 'data', id: 'ncpor-maitri-met-daily' },
            { label: 'India’s Polar Journey', tab: 'india', id: 'maitri' }
          ],
          sourcesUsed: [
            { name: 'Maitri 30-Year Climate Trends', org: 'NCPOR / Polar Science', url: 'https://doi.org/10.1016/j.polar.2021.100684', doi: '10.1016/j.polar.2021.100684' },
            { name: 'NCPOR Station Architecture Dossier', org: 'NCPOR', url: 'https://ncpor.res.in/antarctis/bharati' }
          ]
        };
      } else if (q.includes('indarc') || q.includes('svalbard') || q.includes('himadri') || q.includes('fjord')) {
        responseMsg = {
          id: `resp-${Date.now()}`,
          sender: 'assistant',
          text: 'IndARC is India’s subsurface moored ocean observatory deployed in Kongsfjorden, Svalbard at 192 meters depth, complemented by the Himadri research station in Ny-Ålesund.',
          simpleAnswer: 'It is an underwater robotic anchor packed with sensors that sits near the Arctic seafloor all year long—recording water temperature and salinity even during the pitch-black polar winter under thick ice.',
          scientificExplanation: 'IndARC measures seasonal Atlantic Water (AW) intrusion into the High Arctic. Acoustic Doppler Current Profilers (ADCP) and CTD microCATs document how warm saline water disrupts fjord stratification and teleconnects with the Indian Summer Monsoon.',
          relatedData: [
            { label: 'IndARC CTD Time Series', tab: 'data', id: 'ncpor-himadri-kongsfjorden-ctd' },
            { label: 'Himadri Research Station', tab: 'explore', id: 'himadri' }
          ],
          sourcesUsed: [
            { name: 'Kongsfjorden Moored Oceanographic Physics', org: 'Deep Sea Research / NCPOR', url: 'https://doi.org/10.1016/j.dsr.2019.103130', doi: '10.1016/j.dsr.2019.103130' },
            { name: 'Svalbard Science Forum Portal', org: 'SSF / Kings Bay', url: 'https://research-in-svalbard.net/' }
          ]
        };
      } else if (q.includes('2023') || q.includes('sea ice') || q.includes('record low') || q.includes('nsidc')) {
        responseMsg = {
          id: `resp-${Date.now()}`,
          sender: 'assistant',
          text: 'In winter 2023, Antarctic sea ice extent reached an unprecedented all-time satellite low of 16.96 million km²—over 2.5 million km² below the 1981–2010 average (>5 standard deviations anomaly).',
          simpleAnswer: 'Scientists found that warmer ocean water stored 200 meters below the surface mixed upward, preventing the ocean surface from freezing during the Antarctic winter.',
          scientificExplanation: 'Argo profiling floats and atmospheric reanalyses demonstrated that subsurface warming in the Southern Ocean upper pycnocline, paired with strong circumpolar westerlies, precluded normal sea ice consolidation.',
          relatedData: [
            { label: 'NSIDC Sea Ice Index', tab: 'data', id: 'nsidc-sea-ice-index' },
            { label: 'Data Story: Tale of Two Poles', tab: 'stories', id: 'sea-ice-dynamics-two-poles' }
          ],
          sourcesUsed: [
            { name: 'Record Low Antarctic Sea Ice Cover in 2023', org: 'Communications Earth & Environment', url: 'https://doi.org/10.1038/s43247-023-00961-9', doi: '10.1038/s43247-023-00961-9' },
            { name: 'NSIDC Sea Ice Index Version 3', org: 'NSIDC / NOAA', url: 'https://nsidc.org/data/g02135' }
          ]
        };
      } else if (q.includes('ozone') || q.includes('montreal') || q.includes('halley') || q.includes('cfc')) {
        responseMsg = {
          id: `resp-${Date.now()}`,
          sender: 'assistant',
          text: 'The Antarctic Ozone Hole was discovered in 1985 by British Antarctic Survey scientists at Halley Station. The 1987 Montreal Protocol banned ozone-depleting chlorofluorocarbons (CFCs), and the ozone layer is now on track for full recovery by ~2066.',
          simpleAnswer: 'Chemicals from old spray cans destroyed Earth’s natural UV shield over Antarctica. Thanks to an international global ban, the hole has stopped growing and is slowly healing.',
          scientificExplanation: 'Heterogeneous reactions on Polar Stratospheric Clouds (PSCs) convert stable chlorine reservoirs (HCl, ClONO₂) into reactive free radicals. Spring sunrise triggers catalytic cycles where one chlorine atom destroys 100,000 ozone molecules.',
          relatedData: [
            { label: 'Antarctic Total Column Ozone Series', tab: 'data', id: 'bas-halley-ozone-column' },
            { label: 'Data Story: Healing the Sky', tab: 'stories', id: 'healing-the-antarctic-ozone-hole' }
          ],
          sourcesUsed: [
            { name: 'Large Losses of Total Ozone in Antarctica', org: 'Nature / BAS', url: 'https://doi.org/10.1038/315207a0', doi: '10.1038/315207a0' },
            { name: 'NASA Ozone Watch Annual Summary', org: 'NASA GSFC', url: 'https://ozonewatch.gsfc.nasa.gov/' }
          ]
        }
      } else {
        responseMsg = {
          id: `resp-${Date.now()}`,
          sender: 'assistant',
          text: `Regarding "${textToSend}": I conducted a semantic retrieval across the connected polar repositories (NCPOR, NSIDC, NASA, BAS, SCAR). While general information exists, I couldn't verify a specific peer-reviewed measurement or DOI for that exact query within the connected polar indices.`,
          simpleAnswer: 'To ensure complete scientific integrity, PolarVerse never invents unverified data or simulated findings.',
          scientificExplanation: 'Try asking about Antarctic sea ice, Maitri/Bharati stations, IndARC in Kongsfjorden, ozone hole chemistry, or Himalayan glacier mass balance.',
          isUngrounded: true,
          sourcesUsed: [
            { name: 'NCPOR National Polar Data Centre', org: 'NCPOR', url: 'https://npdc.ncpor.res.in/' },
            { name: 'NSIDC Polar Knowledge Portal', org: 'NSIDC', url: 'https://nsidc.org/' }
          ]
        };
      }

      setMessages((prev) => [...prev, responseMsg]);
      setIsProcessing(false);
    }, 600);
  };

  return (
    <div className="w-full min-h-screen bg-polar-950 text-slate-100 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header Title */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-frost-cyan/20 border border-frost-cyan/50 text-frost-cyan text-xs font-semibold shadow-polar-glow">
            <Bot className="w-4 h-4 text-frost-teal" />
            <span>Source-Grounded Polar Intelligence</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-black text-white font-mono tracking-tight">
            🤖 Ask PolarVerse
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-2xl mx-auto">
            Retrieval-augmented educational AI connected exclusively to authoritative polar datasets, research papers, and station records. Zero hallucinations.
          </p>
        </div>

        {/* Suggested Prompts Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
          <span className="text-xs text-slate-400 font-semibold whitespace-nowrap">Suggested:</span>
          {suggestedPrompts.map((prompt, i) => (
            <button
              key={i}
              onClick={() => handleSendMessage(prompt)}
              className="px-3 py-1.5 rounded-full bg-polar-900 hover:bg-polar-850 border border-polar-800 hover:border-frost-cyan/40 text-xs text-slate-300 whitespace-nowrap transition-colors"
            >
              {prompt}
            </button>
          ))}
        </div>

        {/* Chat Window Container */}
        <div className="bg-polar-900/90 rounded-3xl border border-polar-750 p-4 sm:p-6 shadow-2xl backdrop-blur-xl flex flex-col h-[560px]">
          {/* Messages Scroll Area */}
          <div className="flex-1 overflow-y-auto space-y-4 pr-2">
            {messages.map((msg) => {
              const isUser = msg.sender === 'user';
              return (
                <div
                  key={msg.id}
                  className={`flex items-start gap-3 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
                >
                  <div
                    className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                      isUser
                        ? 'bg-frost-cyan text-polar-950 font-bold text-xs'
                        : 'bg-polar-800 text-frost-cyan border border-frost-cyan/30'
                    }`}
                  >
                    {isUser ? 'You' : <Bot className="w-4 h-4" />}
                  </div>

                  <div
                    className={`max-w-2xl p-4 rounded-2xl text-xs sm:text-sm leading-relaxed space-y-3 ${
                      isUser
                        ? 'bg-frost-cyan text-polar-950 font-medium'
                        : 'bg-polar-950 border border-polar-800 text-slate-200 shadow-sm'
                    }`}
                  >
                    <p>{msg.text}</p>

                    {/* Dual Explanations if assistant */}
                    {!isUser && msg.simpleAnswer && (
                      <div className="p-3.5 rounded-xl bg-polar-900/80 border border-polar-800 space-y-1 text-xs">
                        <span className="font-bold text-frost-cyan block">🧠 Simple Explanation:</span>
                        <p className="text-slate-300">{msg.simpleAnswer}</p>
                      </div>
                    )}

                    {!isUser && msg.scientificExplanation && (
                      <div className="p-3.5 rounded-xl bg-polar-900/80 border border-polar-800 space-y-1 text-xs">
                        <span className="font-bold text-indigo-300 block">🔬 Scientific Deep Dive:</span>
                        <p className="text-slate-300">{msg.scientificExplanation}</p>
                      </div>
                    )}

                    {/* Related Data Links */}
                    {!isUser && msg.relatedData && msg.relatedData.length > 0 && (
                      <div className="pt-1 flex flex-wrap gap-2">
                        {msg.relatedData.map((d, idx) => (
                          <button
                            key={idx}
                            onClick={() => onNavigate(d.tab, d.id)}
                            className="px-2.5 py-1 rounded-lg bg-polar-900 hover:bg-polar-800 border border-frost-cyan/40 text-frost-cyan text-[11px] font-semibold transition-colors flex items-center gap-1"
                          >
                            <Database className="w-3 h-3" />
                            <span>{d.label}</span>
                          </button>
                        ))}
                      </div>
                    )}

                    {/* Sources Citations Ribbon */}
                    {!isUser && msg.sourcesUsed && msg.sourcesUsed.length > 0 && (
                      <div className="pt-2 border-t border-polar-900 text-[11px] text-slate-400 space-y-1">
                        <div className="flex items-center gap-1 font-semibold text-slate-300">
                          <ShieldCheck className="w-3.5 h-3.5 text-frost-teal" />
                          <span>Sources used for this answer:</span>
                        </div>
                        <div className="space-y-1 pl-4">
                          {msg.sourcesUsed.map((src, idx) => (
                            <div key={idx} className="flex items-center justify-between">
                              <span className="text-slate-300">{src.name} ({src.org})</span>
                              <a
                                href={src.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-frost-cyan hover:underline inline-flex items-center gap-0.5 ml-2 font-mono text-[10px]"
                              >
                                {src.doi || 'Verify Source'}
                                <ExternalLink className="w-2.5 h-2.5" />
                              </a>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

            {isProcessing && (
              <div className="flex items-center gap-2 text-xs text-frost-cyan p-3">
                <span className="w-2 h-2 rounded-full bg-frost-cyan animate-ping" />
                <span>Searching verified polar knowledge base...</span>
              </div>
            )}
          </div>

          {/* Chat Input Bar */}
          <div className="pt-4 border-t border-polar-800 flex items-center gap-2">
            <input
              type="text"
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="Ask a question about Antarctic stations, sea ice, ozone, Arctic biology..."
              className="flex-1 px-4 py-3 rounded-2xl bg-polar-950 border border-polar-750 text-xs sm:text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-frost-cyan"
            />
            <button
              onClick={() => handleSendMessage()}
              disabled={!inputQuery.trim() || isProcessing}
              className="p-3 rounded-2xl bg-frost-cyan hover:bg-sky-300 disabled:opacity-40 disabled:cursor-not-allowed text-polar-950 transition-all shadow-polar-glow"
              aria-label="Send query"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
