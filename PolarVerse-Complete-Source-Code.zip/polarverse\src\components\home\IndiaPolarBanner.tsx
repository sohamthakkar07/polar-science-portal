import React from 'react';
import { Flag, ArrowRight, ShieldCheck, MapPin, Compass, Award } from 'lucide-react';
import { NavTab } from '../layout/Navbar';

interface IndiaPolarBannerProps {
  onNavigate: (tab: NavTab) => void;
}

export const IndiaPolarBanner: React.FC<IndiaPolarBannerProps> = ({ onNavigate }) => {
  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-orange-950/40 via-polar-900 to-polar-950 border border-orange-500/30 p-8 sm:p-12 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-orange-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-8 space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-950/80 border border-orange-500/40 text-orange-400 text-xs font-semibold">
              <Flag className="w-3.5 h-3.5" />
              <span>National Polar Showcase • Ministry of Earth Sciences (MoES) & NCPOR</span>
            </div>

            <h2 className="text-2xl sm:text-4xl font-black text-white font-mono tracking-tight leading-tight">
              🇮🇳 India’s Polar Journey: <br className="hidden sm:inline" />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 via-white to-emerald-400">
                Antarctica • Arctic • The Third Pole
              </span>
            </h2>

            <p className="text-sm text-slate-300 leading-relaxed max-w-3xl">
              From the historic First Indian Antarctic Expedition in 1981 led by Dr. S. Z. Qasim to state-of-the-art research stations <strong>Maitri</strong>, <strong>Bharati</strong>, Arctic station <strong>Himadri</strong> in Svalbard, undersea robotic mooring <strong>IndARC</strong>, and Himalayan cryosphere base <strong>Himansh</strong>.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
              <div className="bg-polar-950/80 p-3 rounded-xl border border-polar-800">
                <div className="text-xs font-bold text-orange-400">Maitri (1989)</div>
                <div className="text-[11px] text-slate-400">Schirmacher Oasis, 70°S</div>
              </div>
              <div className="bg-polar-950/80 p-3 rounded-xl border border-polar-800">
                <div className="text-xs font-bold text-orange-400">Bharati (2012)</div>
                <div className="text-[11px] text-slate-400">Larsemann Hills, 69°S</div>
              </div>
              <div className="bg-polar-950/80 p-3 rounded-xl border border-polar-800">
                <div className="text-xs font-bold text-emerald-400">Himadri (2008)</div>
                <div className="text-[11px] text-slate-400">Ny-Ålesund, 79°N Arctic</div>
              </div>
              <div className="bg-polar-950/80 p-3 rounded-xl border border-polar-800">
                <div className="text-xs font-bold text-sky-400">Himansh (2016)</div>
                <div className="text-[11px] text-slate-400">Himalayas, 4,080m a.s.l.</div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-4 flex flex-col justify-center items-start lg:items-end gap-3">
            <button
              onClick={() => onNavigate('india')}
              className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-polar-950 font-bold text-sm shadow-lg transition-all flex items-center justify-center gap-2"
            >
              <span>Explore India's Stations & Expeditions</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
              <ShieldCheck className="w-3.5 h-3.5 text-frost-teal" />
              <span>Grounded in NCPOR & NPDC Data</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
