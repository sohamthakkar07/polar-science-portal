import React, { useState, useMemo } from 'react';
import {
  Award,
  Flame,
  CheckCircle2,
  XCircle,
  HelpCircle,
  BarChart2,
  Sparkles,
  RotateCcw,
  ShieldCheck,
  ArrowRight,
  Compass,
  Zap,
  Lock,
  Unlock
} from 'lucide-react';
import { QUIZ_QUESTIONS, POLAR_BADGES } from '../../data/quizzes';
import { QuizQuestion, QuizType, PolarBadge } from '../../types/polar';
import { useQuiz } from '../../context/QuizContext';
import { ProvenanceBadge } from '../layout/ProvenanceBadge';
import { DataVisualizer } from '../data/DataVisualizer';
import { NavTab } from '../layout/Navbar';

interface QuizCenterProps {
  onNavigate: (tab: NavTab, detailId?: string) => void;
  initialQuestionId?: string;
}

export const QuizCenter: React.FC<QuizCenterProps> = ({ onNavigate, initialQuestionId }) => {
  const { score, streak, bestStreak, recordAnswer, isBadgeUnlocked, resetProgress } = useQuiz();
  const [selectedType, setSelectedType] = useState<QuizType | 'all'>('all');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number>(0);
  const [selectedOptionId, setSelectedOptionId] = useState<string | null>(null);
  const [hasAnsweredCurrent, setHasAnsweredCurrent] = useState<boolean>(false);
  const [showBadgeModal, setShowBadgeModal] = useState<boolean>(false);

  const filteredQuestions = useMemo(() => {
    return QUIZ_QUESTIONS.filter((q) => {
      if (selectedType !== 'all' && q.type !== selectedType) return false;
      return true;
    });
  }, [selectedType]);

  const currentQuestion: QuizQuestion =
    filteredQuestions[currentQuestionIndex] || filteredQuestions[0] || QUIZ_QUESTIONS[0];

  const handleOptionClick = (optionId: string, isCorrect: boolean) => {
    if (hasAnsweredCurrent) return;
    setSelectedOptionId(optionId);
    setHasAnsweredCurrent(true);
    recordAnswer(
      currentQuestion.id,
      isCorrect,
      currentQuestion.topic,
      currentQuestion.badgeRewardId
    );
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < filteredQuestions.length - 1) {
      setCurrentQuestionIndex((prev) => prev + 1);
      setSelectedOptionId(null);
      setHasAnsweredCurrent(false);
    } else {
      setCurrentQuestionIndex(0);
      setSelectedOptionId(null);
      setHasAnsweredCurrent(false);
    }
  };

  const modes: { id: QuizType | 'all'; label: string; emoji: string; desc: string }[] = [
    { id: 'all', label: 'All Challenges', emoji: '🌟', desc: 'Mix of all modes' },
    { id: 'quick-mcq', label: 'Quick Quiz', emoji: '⚡', desc: 'Fast multiple choice' },
    { id: 'myth-fact', label: 'Myth or Fact', emoji: '🧊', desc: 'Debunk misconceptions' },
    { id: 'guess-the-chart', label: 'Guess the Answer', emoji: '📊', desc: 'Interpret real data charts' },
    { id: 'scenario-challenge', label: 'What Would You Choose?', emoji: '🧠', desc: 'Real scientific dilemmas' },
  ];

  return (
    <div className="w-full min-h-screen bg-polar-950 text-slate-100 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto space-y-8">
        {/* Header & Gamification Score Ribbon */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-polar-800 pb-6">
          <div>
            <div className="flex items-center gap-2 text-frost-cyan text-xs font-bold uppercase tracking-wider mb-1">
              <Award className="w-4 h-4 text-amber-400" />
              <span>Polar Science Interactive Mastery</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-black text-white font-mono tracking-tight">
              🎮 Polar Quiz & Challenges
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl">
              Addictive learning grounded in verified scientific observations. Every answer reveals the underlying physical mechanism and authoritative source.
            </p>
          </div>

          {/* User Score & Streak Bar */}
          <div className="flex items-center gap-3 bg-polar-900/90 p-3 rounded-2xl border border-polar-800 shadow-lg">
            <div className="px-3 py-1 bg-polar-950 rounded-xl border border-polar-750">
              <div className="text-[10px] uppercase font-bold text-slate-400">Total Score</div>
              <div className="text-lg font-black text-amber-400 font-mono">{score} pts</div>
            </div>

            <div className="px-3 py-1 bg-polar-950 rounded-xl border border-polar-750 flex items-center gap-2">
              <div>
                <div className="text-[10px] uppercase font-bold text-slate-400">Streak</div>
                <div className="text-lg font-black text-orange-400 font-mono flex items-center gap-1">
                  <Flame className="w-4 h-4 text-orange-400 fill-orange-400" />
                  {streak}x
                </div>
              </div>
            </div>

            <button
              onClick={() => setShowBadgeModal(true)}
              className="px-3 py-2 rounded-xl bg-frost-cyan/20 border border-frost-cyan/40 text-frost-cyan text-xs font-bold hover:bg-frost-cyan/30 transition-colors"
            >
              Badges
            </button>
          </div>
        </div>

        {/* Game Mode Selector */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
          {modes.map((m) => {
            const isActive = selectedType === m.id;
            return (
              <button
                key={m.id}
                onClick={() => {
                  setSelectedType(m.id);
                  setCurrentQuestionIndex(0);
                  setSelectedOptionId(null);
                  setHasAnsweredCurrent(false);
                }}
                className={`p-3 rounded-2xl text-left border transition-all ${
                  isActive
                    ? 'bg-polar-800 border-frost-cyan text-white shadow-polar-glow'
                    : 'bg-polar-900 border-polar-800 text-slate-400 hover:text-slate-200 hover:bg-polar-850'
                }`}
              >
                <div className="text-xl mb-1">{m.emoji}</div>
                <div className="text-xs font-bold text-slate-200">{m.label}</div>
                <div className="text-[10px] text-slate-400 line-clamp-1 mt-0.5">{m.desc}</div>
              </button>
            );
          })}
        </div>

        {/* Active Question Card */}
        <div className="bg-polar-900/90 rounded-3xl border border-polar-750 p-6 sm:p-8 shadow-2xl backdrop-blur-xl space-y-6">
          {/* Question Header */}
          <div className="flex items-center justify-between border-b border-polar-800 pb-4">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-polar-800 border border-polar-700 text-frost-cyan">
                {currentQuestion.topic}
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-polar-950 text-slate-400 border border-polar-800">
                {currentQuestion.difficulty}
              </span>
            </div>

            <div className="text-xs text-slate-400 font-mono">
              Question {currentQuestionIndex + 1} of {filteredQuestions.length}
            </div>
          </div>

          {/* Question Prompt */}
          <div className="space-y-3">
            <h2 className="text-lg sm:text-2xl font-black text-white leading-snug">
              {currentQuestion.question}
            </h2>

            {/* Embedded Chart for Guess The Chart mode */}
            {currentQuestion.visualType === 'chart' && currentQuestion.chartConfigKey && (
              <div className="pt-2">
                <DataVisualizer datasetKey={currentQuestion.chartConfigKey} compact />
              </div>
            )}
          </div>

          {/* Options Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            {currentQuestion.options.map((option) => {
              const isSelected = selectedOptionId === option.id;
              const showCorrectness = hasAnsweredCurrent;

              let btnStyle = 'bg-polar-950 border-polar-800 text-slate-200 hover:bg-polar-850 hover:border-polar-700';

              if (showCorrectness) {
                if (option.isCorrect) {
                  btnStyle = 'bg-emerald-950/80 border-emerald-500 text-emerald-200 shadow-md';
                } else if (isSelected && !option.isCorrect) {
                  btnStyle = 'bg-rose-950/80 border-rose-500 text-rose-200 shadow-md';
                } else {
                  btnStyle = 'bg-polar-950/40 border-polar-900 text-slate-500 opacity-60';
                }
              }

              return (
                <button
                  key={option.id}
                  disabled={hasAnsweredCurrent}
                  onClick={() => handleOptionClick(option.id, option.isCorrect)}
                  className={`p-4 rounded-2xl border text-left text-xs sm:text-sm font-semibold transition-all flex items-start justify-between gap-3 ${btnStyle}`}
                >
                  <span>{option.text}</span>
                  {showCorrectness && option.isCorrect && (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                  )}
                  {showCorrectness && isSelected && !option.isCorrect && (
                    <XCircle className="w-5 h-5 text-rose-400 shrink-0" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Explanation Banner after Answering */}
          {hasAnsweredCurrent && (
            <div className="p-5 rounded-2xl bg-polar-950 border border-frost-cyan/30 space-y-3 animate-in fade-in duration-200">
              <div className="flex items-center gap-2 text-xs font-bold text-frost-cyan uppercase">
                <Sparkles className="w-4 h-4 text-frost-teal" />
                <span>The Scientific Explanation ("Why?")</span>
              </div>
              <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
                {currentQuestion.whyExplanation}
              </p>
              <div className="pt-2 border-t border-polar-900 flex items-center justify-between text-[11px] text-slate-400">
                <div className="flex items-center gap-1 text-slate-300">
                  <ShieldCheck className="w-3.5 h-3.5 text-frost-teal" />
                  <span>Source: {currentQuestion.provenance.sourceOrganization}</span>
                </div>
                <a
                  href={currentQuestion.provenance.originalSourceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-frost-cyan hover:underline"
                >
                  Verify Source &rarr;
                </a>
              </div>
            </div>
          )}

          {/* Footer Controls */}
          <div className="flex items-center justify-between pt-4 border-t border-polar-800">
            <button
              onClick={resetProgress}
              className="text-[11px] text-slate-500 hover:text-slate-300 flex items-center gap-1"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset Score</span>
            </button>

            {hasAnsweredCurrent && (
              <button
                onClick={handleNextQuestion}
                className="px-6 py-2.5 rounded-xl bg-frost-cyan hover:bg-sky-300 text-polar-950 font-bold text-xs flex items-center gap-2 shadow-polar-glow transition-all"
              >
                <span>Next Question</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Badges Modal */}
        {showBadgeModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-polar-950/80 backdrop-blur-md">
            <div className="w-full max-w-2xl bg-polar-900 border border-polar-750 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
              <div className="flex items-center justify-between border-b border-polar-800 pb-4">
                <div className="flex items-center gap-2">
                  <Award className="w-6 h-6 text-amber-400" />
                  <h3 className="text-xl font-bold text-white font-mono">Polar Science Badges</h3>
                </div>
                <button
                  onClick={() => setShowBadgeModal(false)}
                  className="text-slate-400 hover:text-white text-xs px-3 py-1 rounded-lg bg-polar-950 border border-polar-800"
                >
                  Close
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-h-96 overflow-y-auto">
                {POLAR_BADGES.map((badge) => {
                  const unlocked = isBadgeUnlocked(badge.id);
                  return (
                    <div
                      key={badge.id}
                      className={`p-4 rounded-2xl border flex items-start gap-3 transition-all ${
                        unlocked
                          ? 'bg-polar-800 border-amber-500/50 shadow-sm'
                          : 'bg-polar-950/60 border-polar-850 opacity-50'
                      }`}
                    >
                      <div className="text-3xl p-2 rounded-xl bg-polar-950 border border-polar-800 shrink-0">
                        {badge.icon}
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center justify-between">
                          <h4 className="text-xs font-bold text-white">{badge.title}</h4>
                          {unlocked ? (
                            <span className="text-[10px] text-amber-400 font-semibold">Unlocked!</span>
                          ) : (
                            <Lock className="w-3 h-3 text-slate-500" />
                          )}
                        </div>
                        <p className="text-[11px] text-slate-300 leading-relaxed">
                          {badge.description}
                        </p>
                        <span className="text-[9px] font-mono text-frost-cyan uppercase">
                          {badge.category}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
