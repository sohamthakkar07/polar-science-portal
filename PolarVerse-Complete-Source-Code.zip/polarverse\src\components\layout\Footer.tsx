import React from 'react';
import { ShieldCheck, ExternalLink, Globe, BookOpen, Compass, Database, Heart } from 'lucide-react';
import { AUTHORITATIVE_SOURCES } from '../../data/sources';
import { NavTab } from './Navbar';

interface FooterProps {
  onSelectTab: (tab: NavTab) => void;
}

export const Footer: React.FC<FooterProps> = ({ onSelectTab }) => {
  return (
    <footer className="w-full bg-polar-950 border-t border-polar-800 text-slate-400 text-xs mt-20">
      {/* Authoritative Sources Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex items-center gap-2 mb-6">
          <ShieldCheck className="w-5 h-5 text-frost-teal" />
          <h3 className="text-sm font-bold tracking-wider text-slate-200 uppercase">
            Connected Authoritative Scientific Repositories
          </h3>
        </div>

        <p className="text-slate-400 mb-8 max-w-4xl text-xs leading-relaxed">
          <strong className="text-slate-200">Scientific Provenance Mandate:</strong> PolarVerse does <span className="text-slate-200 font-semibold">NOT</span> replace or duplicate NCPOR, NPDC, NASA, NSIDC, BAS, SCAR, COMNAP, or any official polar institution. PolarVerse operates as an <strong className="text-frost-cyan">Interoperability, Experience, and Educational Layer</strong> that links researchers and students directly to original, peer-reviewed, open-access repositories with uncompromised provenance metadata.
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-3 mb-12">
          {AUTHORITATIVE_SOURCES.map((source) => (
            <a
              key={source.id}
              href={source.website}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 rounded-xl bg-polar-900/80 hover:bg-polar-850 border border-polar-800/80 hover:border-frost-cyan/40 transition-all group flex flex-col justify-between"
            >
              <div>
                <div className="text-[11px] font-bold text-slate-200 group-hover:text-frost-cyan flex items-center justify-between">
                  <span>{source.shortName}</span>
                  <ExternalLink className="w-3 h-3 opacity-50 group-hover:opacity-100" />
                </div>
                <div className="text-[10px] text-slate-500 mt-1 line-clamp-1">{source.country}</div>
              </div>
              <div className="text-[9px] text-frost-teal mt-2 font-mono">
                {source.primaryFocus}
              </div>
            </a>
          ))}
        </div>

        {/* Quick Navigation Links & Credits */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pt-8 border-t border-polar-900">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="text-lg">🧊</span>
              <span className="text-sm font-black text-white tracking-wider font-mono">POLARVERSE</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed mb-3">
              Integrated Polar Science Outreach, Knowledge Repository, and Media Dissemination Portal.
            </p>
            <div className="text-[11px] text-slate-500">
              Built with scientific integrity, open data standards, and universal accessibility.
            </div>
          </div>

          <div>
            <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider mb-3">Core Portals</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => onSelectTab('explore')} className="hover:text-frost-cyan transition-colors">
                  🗺️ Interactive Polar Explorer
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('data')} className="hover:text-frost-cyan transition-colors">
                  📊 Scientific Data Catalog
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('stories')} className="hover:text-frost-cyan transition-colors">
                  📖 Signature Data Stories
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('learn')} className="hover:text-frost-cyan transition-colors">
                  🧠 Student Learning ("ELI15")
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider mb-3">Special Features</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => onSelectTab('india')} className="hover:text-frost-cyan transition-colors">
                  🇮🇳 India’s Polar Journey (Maitri & Bharati)
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('ai')} className="hover:text-frost-cyan transition-colors">
                  🤖 Source-Grounded Polar AI
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('quiz')} className="hover:text-frost-cyan transition-colors">
                  🎮 Interactive Polar Quizzes
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('biodiversity')} className="hover:text-frost-cyan transition-colors">
                  🐧 Polar Life & Biodiversity
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider mb-3">Scientific Integrity</h4>
            <p className="text-xs text-slate-400 leading-relaxed mb-3">
              Every data point, DOI citation, station coordinate, and time series in this platform is grounded in real, verifiable scientific measurements.
            </p>
            <div className="flex items-center gap-2 text-[11px] text-frost-teal">
              <ShieldCheck className="w-4 h-4" />
              <span>Zero fabricated scientific claims</span>
            </div>
          </div>
        </div>

        {/* Copyright & Sub-footer */}
        <div className="pt-8 mt-8 border-t border-polar-900 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 gap-3">
          <div>
            © {new Date().getFullYear()} PolarVerse Outreach & Interoperability Portal. Designed for Researchers & Students.
          </div>
          <div className="flex items-center gap-4">
            <span>WCAG 2.1 AA Accessible</span>
            <span>•</span>
            <span>Open Provenance Layer</span>
            <span>•</span>
            <button onClick={() => onSelectTab('admin')} className="hover:text-slate-300">
              Admin Portal
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
