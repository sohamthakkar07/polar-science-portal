import React, { useState } from 'react';
import {
  Compass,
  BookOpen,
  MapPin,
  BarChart3,
  Flame,
  Award,
  Search,
  Bot,
  FileText,
  Flag,
  Image,
  Layers,
  GraduationCap,
  Microscope,
  Menu,
  X,
  ShieldAlert,
  Sparkles,
  ChevronRight
} from 'lucide-react';
import { useAudience } from '../../context/AudienceContext';
import { useQuiz } from '../../context/QuizContext';

export type NavTab =
  | 'home'
  | 'explore'
  | 'learn'
  | 'data'
  | 'stories'
  | 'quiz'
  | 'ai'
  | 'research'
  | 'india'
  | 'biodiversity'
  | 'media'
  | 'admin';

interface NavbarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  onOpenSearch: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentTab, onSelectTab, onOpenSearch }) => {
  const { mode, toggleMode, isStudent } = useAudience();
  const { score, streak } = useQuiz();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'explore' as NavTab, label: 'EXPLORE', icon: MapPin, emoji: '🗺️' },
    { id: 'learn' as NavTab, label: 'LEARN', icon: BookOpen, emoji: '🧠' },
    { id: 'data' as NavTab, label: 'DATA', icon: BarChart3, emoji: '📊' },
    { id: 'stories' as NavTab, label: 'STORIES', icon: Sparkles, emoji: '📖' },
    { id: 'quiz' as NavTab, label: 'QUIZ', icon: Award, emoji: '🎮' },
    { id: 'ai' as NavTab, label: 'POLAR AI', icon: Bot, emoji: '🤖' },
    { id: 'research' as NavTab, label: 'RESEARCH', icon: FileText, emoji: '📚' },
    { id: 'india' as NavTab, label: 'INDIA', icon: Flag, emoji: '🇮🇳' },
    { id: 'biodiversity' as NavTab, label: 'WILDLIFE', icon: Compass, emoji: '🐧' },
    { id: 'media' as NavTab, label: 'MEDIA', icon: Image, emoji: '🖼️' },
  ];

  const handleNavClick = (tab: NavTab) => {
    onSelectTab(tab);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-polar-950/90 backdrop-blur-md border-b border-polar-800/80 shadow-md">
      {/* Top micro-bar: Interoperability Disclaimer + Audience Switcher */}
      <div className="w-full bg-polar-900/90 border-b border-polar-800/60 px-4 py-1 text-xs flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-400">
          <span className="inline-block w-2 h-2 rounded-full bg-frost-teal animate-pulse"></span>
          <span className="hidden sm:inline text-slate-300 font-medium">Interoperability & Outreach Layer</span>
          <span className="hidden md:inline text-slate-400">| Connecting NCPOR, NSIDC, NASA, BAS, SCAR, COMNAP</span>
        </div>

        <div className="flex items-center gap-3">
          {/* Audience Mode Switcher */}
          <button
            onClick={toggleMode}
            className={`flex items-center gap-1.5 px-3 py-0.5 rounded-full text-xs font-semibold transition-all border shadow-sm ${
              isStudent
                ? 'bg-frost-cyan/20 border-frost-cyan/50 text-frost-cyan hover:bg-frost-cyan/30'
                : 'bg-indigo-950/80 border-indigo-500/50 text-indigo-200 hover:bg-indigo-900/60'
            }`}
            title={`Click to switch to ${isStudent ? 'Researcher Mode' : 'Student Mode'}`}
          >
            {isStudent ? (
              <>
                <GraduationCap className="w-3.5 h-3.5 text-frost-cyan" />
                <span>Student Mode</span>
              </>
            ) : (
              <>
                <Microscope className="w-3.5 h-3.5 text-indigo-300" />
                <span>Researcher Mode</span>
              </>
            )}
            <span className="text-[10px] text-slate-400 ml-1 font-normal">(Switch)</span>
          </button>

          {/* User Score & Streak */}
          {score > 0 && (
            <div className="hidden lg:flex items-center gap-2 bg-polar-850 px-2.5 py-0.5 rounded-full border border-polar-700">
              <span className="text-amber-300 font-bold text-xs">{score} pts</span>
              {streak > 1 && (
                <span className="flex items-center text-frost-saffron text-xs font-medium gap-0.5">
                  <Flame className="w-3 h-3 text-orange-400 fill-orange-400" />
                  {streak}x
                </span>
              )}
            </div>
          )}

          {/* Admin link */}
          <button
            onClick={() => handleNavClick('admin')}
            className="text-slate-400 hover:text-slate-200 text-xs flex items-center gap-1"
            title="Curation & Admin Portal"
          >
            <ShieldAlert className="w-3 h-3 text-slate-400" />
            <span className="hidden sm:inline">Admin</span>
          </button>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-14">
          {/* Brand Logo */}
          <button
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-2.5 group text-left focus:outline-none"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-frost-cyan via-polar-500 to-polar-800 flex items-center justify-center shadow-polar-glow group-hover:scale-105 transition-transform">
              <span className="text-xl">🧊</span>
            </div>
            <div>
              <div className="text-lg font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-white via-frost-cyan to-frost-teal leading-tight font-mono">
                POLARVERSE
              </div>
              <div className="text-[10px] font-medium text-slate-400 tracking-widest uppercase">
                Explore • Understand • Discover • Play
              </div>
            </div>
          </button>

          {/* Desktop Nav Links */}
          <nav className="hidden xl:flex items-center space-x-1">
            {navItems.map((item) => {
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold tracking-wide transition-all flex items-center gap-1.5 ${
                    isActive
                      ? 'bg-polar-800 text-frost-cyan shadow-sm border border-frost-cyan/30'
                      : 'text-slate-300 hover:text-white hover:bg-polar-900/60'
                  }`}
                >
                  <span className="text-xs">{item.emoji}</span>
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Search Button & Mobile Hamburger */}
          <div className="flex items-center gap-2">
            <button
              onClick={onOpenSearch}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-polar-900 border border-polar-700/80 text-slate-300 hover:text-white hover:border-frost-cyan/50 text-xs transition-all shadow-inner"
              title="Search Datasets, Stations, Papers, Species (Ctrl+K)"
            >
              <Search className="w-3.5 h-3.5 text-frost-cyan" />
              <span className="hidden sm:inline">Search Polar Science...</span>
              <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-mono bg-polar-950 text-slate-400 rounded border border-polar-800">
                ⌘K
              </kbd>
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="xl:hidden p-2 rounded-lg bg-polar-900 text-slate-300 hover:text-white border border-polar-800"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-polar-950/95 border-b border-polar-800 px-4 pt-2 pb-6 space-y-1 shadow-2xl backdrop-blur-xl">
          <div className="grid grid-cols-2 gap-2 pt-2 pb-3">
            {navItems.map((item) => {
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`flex items-center gap-2 p-2.5 rounded-xl text-xs font-semibold ${
                    isActive
                      ? 'bg-polar-800 text-frost-cyan border border-frost-cyan/30'
                      : 'bg-polar-900/80 text-slate-300 hover:bg-polar-850'
                  }`}
                >
                  <span className="text-base">{item.emoji}</span>
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

          <div className="pt-2 border-t border-polar-800/80 flex items-center justify-between text-xs text-slate-400">
            <span>Role: {isStudent ? 'Student Explorer' : 'Research Scientist'}</span>
            <button
              onClick={toggleMode}
              className="text-frost-cyan hover:underline font-semibold"
            >
              Switch Mode
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
