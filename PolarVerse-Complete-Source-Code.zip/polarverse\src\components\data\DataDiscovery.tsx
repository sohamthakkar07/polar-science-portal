import React, { useState, useMemo } from 'react';
import { Database, Filter, Search, BarChart2, FileText, ExternalLink, ShieldCheck, ArrowRight, Layers, Table as TableIcon, Grid } from 'lucide-react';
import { POLAR_DATASETS } from '../../data/datasets';
import { PolarDataset, PolarTopic, PolarRegion } from '../../types/polar';
import { DatasetDetail } from './DatasetDetail';
import { ProvenanceBadge } from '../layout/ProvenanceBadge';
import { useAudience } from '../../context/AudienceContext';
import { NavTab } from '../layout/Navbar';

interface DataDiscoveryProps {
  onNavigate: (tab: NavTab, detailId?: string) => void;
  initialDatasetId?: string;
  initialTopicFilter?: PolarTopic;
}

export const DataDiscovery: React.FC<DataDiscoveryProps> = ({ onNavigate, initialDatasetId, initialTopicFilter }) => {
  const { isStudent, isResearcher } = useAudience();
  const [selectedDatasetId, setSelectedDatasetId] = useState<string | null>(initialDatasetId || null);
  const [searchQuery, setSearchQuery] = useState('');
  const [topicFilter, setTopicFilter] = useState<string>(initialTopicFilter || 'all');
  const [regionFilter, setRegionFilter] = useState<string>('all');
  const [sourceFilter, setSourceFilter] = useState<string>('all');
  const [viewLayout, setViewLayout] = useState<'grid' | 'table'>(isResearcher ? 'table' : 'grid');

  // If a specific dataset is selected, render the researcher-grade detail page
  const activeDataset = useMemo(() => {
    return POLAR_DATASETS.find((d) => d.id === selectedDatasetId) || null;
  }, [selectedDatasetId]);

  if (activeDataset) {
    return (
      <DatasetDetail
        dataset={activeDataset}
        onBack={() => setSelectedDatasetId(null)}
        onNavigate={onNavigate}
      />
    );
  }

  // Filter datasets
  const filteredDatasets = useMemo(() => {
    return POLAR_DATASETS.filter((d) => {
      if (topicFilter !== 'all' && d.topic !== topicFilter) return false;
      if (regionFilter !== 'all' && d.region !== regionFilter) return false;
      if (sourceFilter !== 'all' && !d.provenance.sourceOrgShort.toLowerCase().includes(sourceFilter.toLowerCase())) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const matchesTitle = d.title.toLowerCase().includes(q) || d.shortTitle.toLowerCase().includes(q);
        const matchesDesc = d.description.toLowerCase().includes(q);
        const matchesVars = d.variables.some((v) => v.name.toLowerCase().includes(q) || v.standardName.toLowerCase().includes(q));
        if (!matchesTitle && !matchesDesc && !matchesVars) return false;
      }
      return true;
    });
  }, [topicFilter, regionFilter, sourceFilter, searchQuery]);

  const topics = ['all', 'Cryosphere', 'Climate', 'Ocean', 'Atmosphere', 'Glaciers'];
  const regions = ['all', 'Antarctic', 'Arctic', 'Himalayan / Third Pole', 'Global Ocean'];
  const sources = [
    { id: 'all', label: 'All Organizations' },
    { id: 'ncpor', label: '🇮🇳 NCPOR / NPDC' },
    { id: 'nsidc', label: '🧊 NSIDC' },
    { id: 'nasa', label: '🛰️ NASA Earthdata' },
    { id: 'bas', label: '🇬🇧 BAS' },
    { id: 'noaa', label: '🌊 NOAA / Argo' },
  ];

  return (
    <div className="w-full min-h-screen bg-polar-950 text-slate-100 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-polar-800 pb-6">
          <div>
            <div className="flex items-center gap-2 text-frost-cyan text-xs font-bold uppercase tracking-wider mb-1">
              <Database className="w-4 h-4" />
              <span>Scientific Data Interoperability & Discovery Catalog</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-black text-white font-mono tracking-tight">
              📊 Polar Science Datasets
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-3xl">
              Discover and visualize real, open-access polar cryospheric, meteorological, and oceanographic datasets from NCPOR, NSIDC, NASA, BAS, and NOAA with preserved provenance and metadata.
            </p>
          </div>

          {/* Layout Toggle */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setViewLayout('grid')}
              className={`p-2 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-all ${
                viewLayout === 'grid'
                  ? 'bg-polar-800 border-frost-cyan text-frost-cyan shadow-sm'
                  : 'bg-polar-900 border-polar-800 text-slate-400 hover:text-white'
              }`}
              title="Card Grid View"
            >
              <Grid className="w-4 h-4" />
              <span className="hidden sm:inline">Cards</span>
            </button>
            <button
              onClick={() => setViewLayout('table')}
              className={`p-2 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-all ${
                viewLayout === 'table'
                  ? 'bg-polar-800 border-frost-cyan text-frost-cyan shadow-sm'
                  : 'bg-polar-900 border-polar-800 text-slate-400 hover:text-white'
              }`}
              title="Researcher Table View"
            >
              <TableIcon className="w-4 h-4" />
              <span className="hidden sm:inline">Table</span>
            </button>
          </div>
        </div>

        {/* Filter Controls Bar */}
        <div className="p-4 rounded-2xl bg-polar-900/90 border border-polar-800 space-y-3 backdrop-blur-md">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {/* Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search variables, title, DOI..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-2 rounded-xl bg-polar-950 border border-polar-750 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-frost-cyan"
              />
            </div>

            {/* Topic Filter */}
            <select
              value={topicFilter}
              onChange={(e) => setTopicFilter(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-polar-950 border border-polar-750 text-xs text-slate-200 focus:outline-none focus:border-frost-cyan"
            >
              <option value="all">All Scientific Topics</option>
              {topics.filter((t) => t !== 'all').map((t) => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>

            {/* Region Filter */}
            <select
              value={regionFilter}
              onChange={(e) => setRegionFilter(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-polar-950 border border-polar-750 text-xs text-slate-200 focus:outline-none focus:border-frost-cyan"
            >
              <option value="all">All Geographic Regions</option>
              {regions.filter((r) => r !== 'all').map((r) => (
                <option key={r} value={r}>{r}</option>
              ))}
            </select>

            {/* Source Organization Filter */}
            <select
              value={sourceFilter}
              onChange={(e) => setSourceFilter(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-polar-950 border border-polar-750 text-xs text-slate-200 focus:outline-none focus:border-frost-cyan"
            >
              {sources.map((s) => (
                <option key={s.id} value={s.id}>{s.label}</option>
              ))}
            </select>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-400 pt-1 border-t border-polar-800/60">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-slate-200">{filteredDatasets.length}</span>
              <span>authoritative datasets available</span>
            </div>
            {(topicFilter !== 'all' || regionFilter !== 'all' || sourceFilter !== 'all' || searchQuery) && (
              <button
                onClick={() => {
                  setTopicFilter('all');
                  setRegionFilter('all');
                  setSourceFilter('all');
                  setSearchQuery('');
                }}
                className="text-frost-cyan hover:underline"
              >
                Reset All Filters
              </button>
            )}
          </div>
        </div>

        {/* Datasets View: Grid or Table */}
        {filteredDatasets.length === 0 ? (
          <div className="text-center py-16 bg-polar-900/40 rounded-3xl border border-polar-800 text-slate-400">
            <Database className="w-10 h-10 text-slate-600 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-300">No matching polar datasets found</h3>
            <p className="text-xs text-slate-500 mt-1">Try relaxing your topic or organization filter.</p>
          </div>
        ) : viewLayout === 'table' ? (
          <div className="overflow-x-auto bg-polar-900/90 rounded-2xl border border-polar-750 shadow-xl">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-polar-950 text-slate-400 font-semibold border-b border-polar-800">
                <tr>
                  <th className="p-4">Dataset Title</th>
                  <th className="p-4">Topic & Region</th>
                  <th className="p-4">Source Organization</th>
                  <th className="p-4">Temporal Range</th>
                  <th className="p-4">Variables</th>
                  <th className="p-4">DOI</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-polar-800/60">
                {filteredDatasets.map((d) => (
                  <tr key={d.id} className="hover:bg-polar-850/50">
                    <td className="p-4 font-bold text-white max-w-xs">{d.shortTitle}</td>
                    <td className="p-4">
                      <div className="flex flex-col gap-1">
                        <span className="text-frost-cyan font-semibold">{d.topic}</span>
                        <span className="text-slate-400 text-[10px]">{d.region}</span>
                      </div>
                    </td>
                    <td className="p-4 text-slate-300">{d.provenance.sourceOrgShort}</td>
                    <td className="p-4 font-mono text-[11px]">
                      {d.temporalCoverage.startDate.slice(0, 4)} – {d.temporalCoverage.endDate.slice(0, 4)}
                    </td>
                    <td className="p-4">
                      <span className="text-xs text-amber-300 font-mono">
                        {d.variables.map((v) => v.name).join(', ')}
                      </span>
                    </td>
                    <td className="p-4 font-mono text-[10px] text-frost-teal">
                      {d.provenance.doi || 'N/A'}
                    </td>
                    <td className="p-4 text-right space-x-2 whitespace-nowrap">
                      <button
                        onClick={() => setSelectedDatasetId(d.id)}
                        className="px-3 py-1.5 rounded-lg bg-frost-cyan text-polar-950 hover:bg-sky-300 text-xs font-bold transition-colors"
                      >
                        Inspect
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredDatasets.map((dataset) => (
              <div
                key={dataset.id}
                className="p-6 rounded-2xl bg-polar-900/90 border border-polar-750 hover:border-frost-cyan/50 shadow-xl transition-all flex flex-col justify-between space-y-4 group"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-frost-cyan/20 border border-frost-cyan/40 text-frost-cyan">
                      {dataset.topic}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">
                      {dataset.temporalCoverage.startDate.slice(0, 4)} – {dataset.temporalCoverage.endDate.slice(0, 4)}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-white group-hover:text-frost-cyan transition-colors">
                    {dataset.title}
                  </h3>

                  <p className="text-xs text-slate-300 leading-relaxed line-clamp-3">
                    {isStudent ? dataset.studentSummary : dataset.description}
                  </p>

                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {dataset.variables.map((v, i) => (
                      <span key={i} className="px-2 py-0.5 rounded bg-polar-950 border border-polar-800 text-[10px] font-mono text-slate-300">
                        {v.name} ({v.unit})
                      </span>
                    ))}
                  </div>
                </div>

                <div className="space-y-3 pt-3 border-t border-polar-800/80">
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <div className="flex items-center gap-1 text-slate-300">
                      <ShieldCheck className="w-3.5 h-3.5 text-frost-teal" />
                      <span>{dataset.provenance.sourceOrganization}</span>
                    </div>
                    {dataset.provenance.doi && (
                      <span className="font-mono text-[10px] text-frost-cyan">DOI: {dataset.provenance.doi}</span>
                    )}
                  </div>

                  <div className="flex items-center gap-2 pt-1">
                    <button
                      onClick={() => setSelectedDatasetId(dataset.id)}
                      className="flex-1 px-4 py-2.5 rounded-xl bg-frost-cyan hover:bg-sky-300 text-polar-950 font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-polar-glow"
                    >
                      <BarChart2 className="w-4 h-4" />
                      <span>Visualize & Inspect</span>
                    </button>

                    <a
                      href={dataset.provenance.originalSourceUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2.5 rounded-xl bg-polar-950 hover:bg-polar-800 border border-polar-750 text-slate-300 hover:text-white transition-colors"
                      title="Visit Original Repository"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
